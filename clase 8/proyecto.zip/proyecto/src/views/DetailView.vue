<template>
  <div>
    <h2>Detail page</h2>
    Id: {{ $route.params.id }}
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>