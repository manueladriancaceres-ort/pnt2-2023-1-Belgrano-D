<template>
  <div>
    <h2>System page</h2>
    <button @click="irAbout">Ir a About</button>
  </div>
</template>

<script>
export default {
  methods: {
    irAbout() {
      this.$router.push("/about")
    }
  }
}
</script>

<style>

</style>