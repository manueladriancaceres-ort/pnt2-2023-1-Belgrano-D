<template>
  <div>
    <h2>About page</h2>
  </div>
</template>

<style>

</style>
