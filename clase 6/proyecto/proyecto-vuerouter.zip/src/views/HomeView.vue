<script>
</script>

<template>
  <div>
    <h2>Home page</h2>
  </div>
</template>
